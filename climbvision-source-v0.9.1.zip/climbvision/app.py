from pathlib import Path
import tempfile
import cv2
import numpy as np
import urllib.request
import subprocess
import hashlib
import streamlit as st
from analysis import MODEL_URLS, analyze_video, make_feedback, detect_motion_events
from holds import background_from_video, detect_holds, annotate_holds, segment_color, sample_color, sample_color_robust, suggested_box, remove_hold_near, reindex_holds, normalize_reviewed_holds
from streamlit_image_coordinates import streamlit_image_coordinates
from PIL import Image
from roboflow_detector import detect_with_roboflow, filter_predictions_by_color, BOULDERVISION_MODEL
from evaluation import evaluate_boxes, ground_truth_template, read_ground_truth
from result_cache import fingerprint, cache_root, load_result, save_result, clear_cache

st.set_page_config(page_title='ClimbVision', page_icon='🧗', layout='wide')
st.title('ClimbVision')
st.caption('Climbing movement analysis • experimental prototype v0.9.1')
st.write('Upload a fixed-camera video of one climber. The app estimates body landmarks and reports descriptive movement measurements, not validated technique scores.')

if 'analysis_result' not in st.session_state:
    st.session_state.analysis_result = None

def browser_compatible_video(source: str, destination: str):
    """Convert OpenCV mp4v output to browser-friendly H.264 + yuv420p.

    Returns (video bytes, was_converted, warning). Keeps a usable download fallback.
    """
    raw = Path(source).read_bytes()
    try:
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        command = [exe, '-hide_banner', '-loglevel', 'error', '-y', '-i', source,
                   '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23',
                   '-pix_fmt', 'yuv420p', '-movflags', '+faststart', destination]
        subprocess.run(command, capture_output=True, text=True, check=True, timeout=180)
        if Path(destination).stat().st_size == 0:
            raise RuntimeError('H.264 conversion returned an empty file')
        return Path(destination).read_bytes(), True, None
    except (ImportError, subprocess.SubprocessError, OSError, RuntimeError) as error:
        return raw, False, str(error)


@st.cache_resource(show_spinner='Downloading pose model (first use of each model only)...')
def get_model(model_name):
    filename = {'Lite (fast)': 'pose_landmarker_lite.task',
                'Full (recommended)': 'pose_landmarker_full.task',
                'Heavy (slower)': 'pose_landmarker_heavy.task'}[model_name]
    path = Path.home() / '.cache' / 'climbvision' / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    if not path.exists() or path.stat().st_size == 0:
        urllib.request.urlretrieve(MODEL_URLS[model_name], path)
    return str(path)

st.subheader('Pose tracking model')
model_name = st.selectbox('Choose model', list(MODEL_URLS), index=1,
    help='Full/Heavy generally trade speed for quality. Neither guarantees accuracy on climbing poses. Compare the annotated outputs.')

uploaded = st.file_uploader('Choose a climbing video', type=['mp4', 'mov', 'avi'])
sample_fps = st.slider('Pose analysis FPS', 2, 20, 10, help='How often MediaPipe measures body pose. Does not control SAM 2 inference or export FPS.')
st.info('Select the area where the climber moves. Keep the floor and equipment outside the selection. The crop is applied BEFORE pose detection.')
if uploaded:
    with tempfile.TemporaryDirectory() as preview_dir:
        preview_path = str(Path(preview_dir) / ('preview' + Path(uploaded.name).suffix.lower()))
        Path(preview_path).write_bytes(uploaded.getvalue())
        cap = cv2.VideoCapture(preview_path)
        ok, preview = cap.read()
        cap.release()
    if ok:
        st.subheader('Climber tracking region')
        left = st.slider('Left boundary (% of frame)', 0, 90, 15)
        right = st.slider('Right boundary (% of frame)', 10, 100, 90)
        top = st.slider('Top boundary (% of frame)', 0, 90, 3)
        bottom = st.slider('Bottom boundary (% of frame)', 10, 100, 78)
        roi = (left / 100, top / 100, right / 100, bottom / 100)
        if left >= right or top >= bottom:
            st.error('Invalid crop: left must be less than right, and top less than bottom.')
            st.stop()
        h, w = preview.shape[:2]
        original_frame = preview.copy()
        x1, y1, x2, y2 = int(w*roi[0]), int(h*roi[1]), int(w*roi[2]), int(h*roi[3])
        cv2.rectangle(preview, (x1, y1), (x2, y2), (0, 215, 255), max(2, w//320))
        st.image(cv2.cvtColor(preview, cv2.COLOR_BGR2RGB), caption='Only the outlined region is analyzed', width='stretch')
        st.subheader('Climbing route hold review (experimental)')
        detect_route = st.checkbox('Detect route holds by color', value=True)
        hold_settings = None
        if detect_route:
            st.caption('Use a typical bouldering wall with distinct, saturated same-color holds. Select the color of the plastic, not the wall. Black, gray, and white holds need a different detector.')
            st.info('Muted or shadowed holds may require lower saturation and smaller area thresholds. Use Preview before analyzing.')
            color = st.color_picker('Manual route color (fallback)', '#e83438')
            robust_sampling = st.checkbox('Use shadow-resistant color sampling', value=True, help='Uses saturated pixels and circular hue averaging from a wider patch. May include the wall on small holds; preview suggestions before analysis.')
            st.markdown('**Click a route hold in the first video frame to sample its color**')
            st.caption('Click near the middle of a visible colored hold, avoiding skin, shadows, and highlights. This works directly on the picture; no X/Y sliders required. The image includes the full frame so the selected point maps correctly even when you use a tracking crop.')
            display_width = min(w, 900)
            display_height = max(1, round(h * display_width / w))
            image_rgb = cv2.cvtColor(original_frame, cv2.COLOR_BGR2RGB)
            clickable_image = Image.fromarray(image_rgb).resize((display_width, display_height), Image.Resampling.LANCZOS)
            upload_id = hashlib.sha256(uploaded.getvalue()).hexdigest()[:16]
            epoch_key = f'hold_click_epoch_{upload_id}'
            if epoch_key not in st.session_state:
                st.session_state[epoch_key] = 0
            point = streamlit_image_coordinates(clickable_image, key=f'hold_click_{upload_id}_{st.session_state[epoch_key]}', width=display_width)
            sample_key = f'hold_sample_{upload_id}'
            if point is not None:
                click_x, click_y = int(point['x']), int(point['y'])
                px = min(w-1, max(0, round((click_x + .5) * w / display_width - .5)))
                py = min(h-1, max(0, round((click_y + .5) * h / display_height - .5)))
                st.session_state[sample_key] = (px, py)
            if sample_key in st.session_state:
                px, py = st.session_state[sample_key]
                color = (sample_color_robust(original_frame, px, py, radius=max(5, round(w / 100)))
                     if robust_sampling else sample_color(original_frame, px, py, radius=max(3, round(w / 450))))
                marked = original_frame.copy()
                cv2.drawMarker(marked, (px, py), (0, 230, 255), cv2.MARKER_CROSS, max(20, w//45), 3)
                st.image(cv2.cvtColor(marked, cv2.COLOR_BGR2RGB), caption=f'Selected sample at ({px}, {py}) in original video pixels', width=display_width)
                a, b = st.columns([1, 3])
                with a:
                    st.color_picker('Detected color', color, disabled=True, key=f'swatch_{upload_id}_{color}')
                with b:
                    st.success(f'Sampled color: {color}. This color is now used for the hold preview and analysis.')
                if st.button('Clear sampled color', key=f'clear_{upload_id}'):
                    del st.session_state[sample_key]
                    st.session_state[epoch_key] += 1
                    st.rerun()
            else:
                st.info('Click a colored hold above to select it. Until then, the manual color picker is used.')
            hue_tolerance = st.slider('Color tolerance (hue)', 3, 45, 20)
            min_saturation = st.slider('Minimum color saturation', 10, 220, 30)
            min_area = st.slider('Minimum component area (at processed resolution)', 10, 1200, 25)
            with st.expander('Advanced suggestion filtering', expanded=False):
                min_fill_ratio = st.slider('Minimum matching-color coverage inside box', .15, .85, .38, .05,
                                           help='Higher values reject boxes containing mostly wall, clothing, or background.')
                min_thickness = st.slider('Remove thin strips / small fragments (pixels)', 0.0, 5.0, 2.1, .5,
                                           help='Higher values suppress colored tape and narrow streaks, but may miss tiny holds.')
                exclude_boundary = st.checkbox('Reject partial boxes at tracking-region edge', value=True,
                                                help='Turn off if a real route hold touches the crop boundary.')
            hold_settings = dict(route_color=color, hue_tolerance=hue_tolerance,
                                 min_saturation=min_saturation, min_area=min_area,
                                 min_fill_ratio=min_fill_ratio, min_thickness=min_thickness,
                                 exclude_boundary=exclude_boundary)
            st.markdown('### Automatic hold proposals')
            suggestion_method = st.radio('Suggestion method',
                ['Trained hold detector (Roboflow)', 'Legacy HSV color regions'], horizontal=True,
                help='The trained detector identifies possible holds first. HSV only finds colored blobs.')
            if suggestion_method == 'Trained hold detector (Roboflow)':
                st.caption('Uses the publicly listed BoulderVision climbing-hold model. This option sends the FIRST VIDEO FRAME to Roboflow for hosted inference. Usage may consume Roboflow credits. No full video is sent by this feature.')
                rf_key = st.text_input('Roboflow API key', type='password', key=f'roboflow_key_{upload_id}',
                    help='Obtain a key from your Roboflow account. It stays in this Streamlit session and is not exported into route JSON.')
                rf_model = st.text_input('Roboflow model ID', value=BOULDERVISION_MODEL,
                    key=f'roboflow_model_{upload_id}')
                rf_confidence = st.slider('Minimum hold detection confidence', .10, .95, .35, .05)
                only_route_color = st.checkbox('Keep only detections matching the selected hold color', value=True)
                color_match_threshold = st.slider('Minimum matching-color fraction', .03, .60, .12, .03)
                st.caption('Model detections and color matches are proposals, not verified holds. Review all boxes before tracking.')
            st.markdown('### Review and correct route holds')
            st.caption('Review the suggestions before tracking. Incorrect or missed holds can be removed or added manually.')
            edit_key = f'hold_review_{upload_id}'
            if edit_key not in st.session_state:
                st.session_state[edit_key] = []
            generate_label = ('Generate trained hold suggestions' if suggestion_method == 'Trained hold detector (Roboflow)' else 'Generate color-based suggestions')
            if st.button(generate_label, key=f'generate_{upload_id}'):
                if suggestion_method == 'Trained hold detector (Roboflow)':
                    try:
                        with st.spinner('Requesting trained hold detections for the first frame...'):
                            proposals = detect_with_roboflow(original_frame, rf_key,
                                model_id=rf_model, threshold=rf_confidence,
                                roi=(x1, y1, x2, y2))
                            raw_count = len(proposals)
                            if only_route_color:
                                proposals = filter_predictions_by_color(original_frame, proposals, color,
                                    min_match=color_match_threshold, hue_tolerance=hue_tolerance,
                                    min_saturation=min_saturation)
                        st.session_state[edit_key] = reindex_holds(proposals)
                        st.success(f'Trained detector: {raw_count} hold proposals; {len(proposals)} retained. Review boxes below.')
                    except Exception as exc:
                        st.error(f'Roboflow detection failed (previous reviewed holds preserved): {exc}')
                else:
                    scale = min(1., 960 / max(w, h))
                    size = (max(2, int(w*scale)//2*2), max(2, int(h*scale)//2*2))
                    from analysis import crop_bounds
                    bg = cv2.resize(original_frame, size)
                    proposals = detect_holds(bg, crop_bounds(*size, roi), **hold_settings)
                    st.session_state[edit_key] = reindex_holds([{
                        'x': round(q['x']*w/size[0]), 'y': round(q['y']*h/size[1]),
                        'w': max(1,round(q['w']*w/size[0])), 'h': max(1,round(q['h']*h/size[1]))
                    } for q in proposals])
            edit_mode = st.radio('Editing action', ['Add a hold', 'Remove a hold'], horizontal=True,
                                 key=f'edit_mode_{upload_id}')
            box_radius = st.slider('New hold approximate radius (pixels)', 8, 100, 30, key=f'holdradius_{upload_id}')
            editor_frame = original_frame.copy()
            for hold in st.session_state[edit_key]:
                xx,yy,ww,hh = (int(hold[k]) for k in ('x','y','w','h'))
                cv2.rectangle(editor_frame, (xx,yy), (xx+ww,yy+hh), (50,230,50), max(2,w//500))
                cv2.putText(editor_frame, hold['hold_id'], (xx,max(12,yy-5)), cv2.FONT_HERSHEY_SIMPLEX,
                            max(.5,w/1600), (50,230,50), 2)
            editor_image = Image.fromarray(cv2.cvtColor(editor_frame, cv2.COLOR_BGR2RGB)).resize(
                (display_width,display_height), Image.Resampling.LANCZOS)
            st.caption('Click on the image below to add a hold or remove an incorrect box. Green boxes are the reviewed map.')
            revision_key = f'hold_revision_{upload_id}'
            if revision_key not in st.session_state:
                st.session_state[revision_key] = 0
            click = streamlit_image_coordinates(editor_image, width=display_width,
                key=f'hold_editor_{upload_id}_{st.session_state[revision_key]}')
            if click is not None:
                ex = min(w-1, max(0, int(click['x']*w/display_width)))
                ey = min(h-1, max(0, int(click['y']*h/display_height)))
                if edit_mode == 'Add a hold':
                    item = suggested_box(original_frame, ex, ey, color, radius=box_radius)
                    st.session_state[edit_key] = reindex_holds(st.session_state[edit_key]+[item])
                else:
                    new_list, removed = remove_hold_near(st.session_state[edit_key], ex, ey)
                    if removed:
                        st.session_state[edit_key] = reindex_holds(new_list)
                    else:
                        st.warning('Click inside an existing green box to remove it.')
                st.session_state[revision_key] += 1
                st.rerun()
            c1,c2 = st.columns(2)
            c1.metric('Reviewed hold boxes', len(st.session_state[edit_key]))
            if c2.button('Clear all boxes', key=f'resetreview_{upload_id}'):
                st.session_state[edit_key] = []
                st.session_state[revision_key] += 1
                st.rerun()
            import json
            st.download_button('Download reviewed route JSON',
                json.dumps({'frame_width':w,'frame_height':h,'holds':st.session_state[edit_key]},indent=2),
                file_name='climbvision_reviewed_route.json',mime='application/json', on_click='ignore',
                key=f'routejson_{upload_id}')
            saved_route = st.file_uploader('Load previously reviewed route JSON', type=['json'],
                                            key=f'loadroute_{upload_id}')
            if saved_route is not None and st.button('Load this route',key=f'importreview_{upload_id}'):
                try:
                    payload=json.loads(saved_route.getvalue())
                    if (int(payload['frame_width']),int(payload['frame_height'])) != (w,h):
                        st.error('Saved route dimensions differ from this video. Use a matching video.')
                    else:
                        valid=[dict(x=int(b['x']),y=int(b['y']),w=int(b['w']),h=int(b['h'])) for b in payload['holds']]
                        st.session_state[edit_key]=reindex_holds(valid)
                        st.session_state[revision_key]+=1
                        st.rerun()
                except (ValueError,KeyError,TypeError) as exc:
                    st.error(f'Invalid route file: {exc}')
            st.markdown('### Camera-motion compensation')
            tracker = st.radio('Hold tracking algorithm',
                ['Fast Preview (OpenCV, no SAM)', 'SAM 2.1 (AI masks)', 'OpenCV wall alignment (old)'], horizontal=True,
                help='Use Fast Preview for quick iterations; SAM 2 is significantly slower on M3.')
            track_wall = tracker in ('Fast Preview (OpenCV, no SAM)', 'OpenCV wall alignment (old)')
            hold_settings = {'reviewed_holds': normalize_reviewed_holds(
                st.session_state[edit_key], w, h), 'track_wall': track_wall,
                'tracker': tracker}
            if tracker == 'SAM 2.1 (AI masks)':
                st.info('SAM 2 tracks the holds you have reviewed. It does NOT automatically recognize all holds. Use a short clip and up to 16 prompts initially.')
                hold_settings['sam_model'] = st.selectbox('SAM 2.1 checkpoint size',
                    ['Tiny (M3 recommended)', 'Small'])
                hold_settings['sam_checkpoint'] = st.text_input('SAM 2 checkpoint path',
                    str(Path.home() / 'Downloads' / 'sam2' / 'checkpoints' / 'sam2.1_hiera_tiny.pt'),
                    help='Download the corresponding model from the official SAM 2 repository; see README.')
                hold_settings['sam_device'] = st.selectbox('Inference device', ['mps', 'cpu'], index=0)
                hold_settings['sam_fps'] = st.slider('SAM 2 inference FPS', 1, 5, 2, help='Sparse AI hold reference frames; OpenCV optical flow fills the intervening original video frames. Lower values are faster, but may reduce tracking accuracy.')
                st.caption('SAM FPS and pose FPS are independent. Export retains original video FPS; intermediate hold positions use optical flow.')
            else:
                st.caption('FAST PREVIEW: skips SAM 2 entirely; uses OpenCV wall alignment. Boxes may drift on overhangs and camera pans.')
            if not st.session_state[edit_key]:
                st.warning('No reviewed holds selected. Add route holds before analyzing if you want proximity outputs.')
        else:
            hold_settings = None
    else:
        st.error('Could not preview video. Try MP4 H.264.')
        st.stop()
else:
    roi = (0.15, 0.03, 0.90, 0.78)
if uploaded:
    preview_seconds = st.slider('Analyze first N seconds (quick tests)', 3, 90, 10, help='Limit processing time while testing. Increase for full evaluation.')
    st.caption('Speed tip: Fast Preview + Lite pose model + 5 FPS + a short clip avoids SAM 2 entirely. Export still uses source FPS.')
if uploaded:
    use_cache = st.checkbox('Reuse saved analysis when settings are unchanged', value=True, help='Completed runs are stored on this Mac. Identical videos and tracking settings reuse results, including the exported video.')
    with st.expander('Manage analysis cache'):
        st.caption(f'Location: {cache_root()} · Cached videos may contain private footage. Entries persist across app restarts.')
        if st.button('Delete all saved ClimbVision analyses'):
            clear_cache(cache_root())
            st.success('Saved analyses cleared. Current on-screen results remain until the next run.')
if uploaded and st.button('Analyze climb', type='primary'):
    # Invalidate old results immediately; unsuccessful analysis must not show stale charts.
    st.session_state.analysis_result = None
    status_box = st.status('Preparing analysis...', expanded=True)
    progress_bar = st.progress(0, text='Preparing video...')
    stage_line = st.empty()
    def update_progress(stage, fraction, detail=''):
        progress_bar.progress(min(100, max(0, int(fraction*100))), text=f'{stage}: {detail}')
        stage_line.caption(f'Current stage: {stage} — {detail}')
    with status_box:
        try:
            with tempfile.TemporaryDirectory() as workdir:
                src = str(Path(workdir) / ('input' + Path(uploaded.name).suffix.lower()))
                dst = str(Path(workdir) / 'annotated.mp4')
                compatible = str(Path(workdir) / 'annotated_h264.mp4')
                upload_bytes = uploaded.getvalue()
                key = fingerprint(upload_bytes, model_name, sample_fps, roi, hold_settings, preview_seconds)
                cached = load_result(cache_root(), key) if use_cache else None
                if cached is not None:
                    cached['cache_hit'] = True
                    st.session_state.analysis_result = cached
                    update_progress('Cached analysis', 1., 'Loaded existing results; SAM 2 and MediaPipe were skipped')
                    status_box.update(label='Loaded from disk cache — no AI inference', state='complete', expanded=False)
                    st.rerun()
                Path(src).write_bytes(upload_bytes)
                df, info = analyze_video(src, dst, get_model(model_name), sample_fps, roi=roi, hold_settings=hold_settings, max_seconds=preview_seconds, progress_callback=update_progress)
                update_progress('Movement metrics', .98, 'Calculating events')
                metrics, events = detect_motion_events(df)
                update_progress('Browser video conversion', .99, 'Encoding H.264 for playback')
                video_bytes, converted, conversion_warning = browser_compatible_video(dst, compatible)
                import pandas as pd
                st.session_state.analysis_result = {
                    'video_bytes': video_bytes,
                    'converted': converted,
                    'conversion_warning': conversion_warning,
                    'df': df,
                    'info': info,
                    'metrics': metrics,
                    'events': events,
                    'holds_df': pd.DataFrame(info['holds']),
                    'near_df': pd.DataFrame(info['near_rows']),
                    'wall_df': pd.DataFrame(info.get('wall_tracking', [])),
                    'hold_enabled': hold_settings is not None,
                    'source_hash': hashlib.sha256(upload_bytes).hexdigest(),
                    'source_name': uploaded.name,
                    'model_name': model_name,
                    'sample_fps': sample_fps,
                    'processing_seconds_limit': preview_seconds,
                    'cache_hit': False,
                }
                if use_cache:
                    save_result(cache_root(), key, st.session_state.analysis_result)
                update_progress('Complete', 1., 'Results are ready below')
                status_box.update(label='Analysis completed', state='complete', expanded=False)
        except Exception as exc:
            status_box.update(label='Analysis failed', state='error', expanded=True)
            st.error(f'Could not analyze video: {exc}')

# Render from session state, not inside the Analyze button branch. All Streamlit
# widget interactions (including downloads) can rerun the script safely.
result = st.session_state.analysis_result
if result is not None:
    if uploaded is None or hashlib.sha256(uploaded.getvalue()).hexdigest() != result['source_hash']:
        st.info('The uploaded video changed. Click Analyze climb to produce results for the new video.')
    else:
        df, info = result['df'], result['info']
        metrics, events = result['metrics'], result['events']
        holds_df, near_df = result['holds_df'], result['near_df']
        wall_df = result['wall_df']
        st.subheader('Tracking results')
        st.caption('Source: ' + ('Disk cache — inference skipped' if result.get('cache_hit') else 'Fresh analysis'))
        st.caption(f"Results for {result['source_name']} · {result['model_name']} · requested {result['sample_fps']} FPS. Results remain visible while you download files or adjust controls, until you run a new analysis.")
        st.caption('A detected pose is not proof that every joint is correctly located. Inspect the skeleton overlay.')
        a, b, c = st.columns(3)
        a.metric('Frames analyzed', info['frames_analyzed'])
        b.metric('Tracking coverage', f"{df['detected'].mean():.0%}")
        c.metric('Clip analyzed', f"{info['seconds_analyzed']:.1f}s")
        st.caption(f"Video export: {info.get('export_fps', 'unknown')} FPS · Pose sampling: {info.get('sample_rate_fps', 'unknown')} FPS · SAM sampling: {info.get('sam_sample_rate_fps', 'off')} FPS ({info.get('sam_anchor_frames', 0)} anchor frames) · Hold tracker: {info.get('hold_tracking_mode', 'unknown')}")
        st.subheader('Annotated video — watch here')
        st.video(result['video_bytes'], format='video/mp4')
        if not result['converted']:
            st.warning('H.264 conversion was unavailable, so this is the original MP4V file. Some browsers cannot play it inline. Download the file or install the dependencies from requirements.txt. Conversion issue: ' + str(result['conversion_warning']))
        st.download_button('Download annotated video', data=result['video_bytes'],
                           file_name='climbvision_v0_9_1_annotated.mp4', mime='video/mp4',
                           on_click='ignore', key='download_annotated')
        if df['detected'].mean() < 0.3:
            st.warning('Very low valid pose coverage. Expand or reposition the crop and try again. Do not interpret the motion measurements as technique analysis.')
        if result['hold_enabled']:
            st.subheader('Reviewed route holds')
            st.caption('Only the reviewed boxes are used. These are manually assisted annotations, not verified neural-network detections.')
            st.metric('Candidate regions', len(holds_df))
            if not holds_df.empty:
                st.dataframe(holds_df, hide_index=True, width='stretch')
                st.download_button('Download hold candidates CSV', holds_df.to_csv(index=False).encode(),
                                   'climbvision_holds.csv', 'text/csv', on_click='ignore')
            if not wall_df.empty:
                st.subheader('Wall tracking reliability')
                st.metric('Frames with confirmed wall alignment', f"{wall_df['aligned'].mean():.1%}")
                st.dataframe(wall_df, width='stretch', hide_index=True)
                st.download_button('Download wall tracking diagnostics', wall_df.to_csv(index=False).encode(),
                                   'climbvision_wall_tracking.csv', 'text/csv', on_click='ignore')
                st.caption('This is alignment availability, not verified hold-detection accuracy. Holds are hidden when alignment fails.')
            st.subheader('Hold detection evaluation — reference frame')
            st.caption('Create ground-truth bounding boxes for the FIRST video frame only. Coordinates refer to the resized analysis frame (maximum dimension 960 px), not the original upload. The evaluation uses one-to-one IoU matching at 0.5; this is NOT video tracking accuracy.')
            if not holds_df.empty:
                template = ground_truth_template(holds_df)
                st.download_button('Download ground-truth starter CSV', template.to_csv(index=False).encode(), 'climbvision_ground_truth_starter.csv', 'text/csv', key='gt_template', on_click='ignore')
                st.caption('Edit the CSV to describe all true route holds, including any missed detections, then upload it. Do not simply accept proposed boxes as ground truth.')
                gt_upload = st.file_uploader('Upload manually corrected ground-truth CSV (x, y, w, h)', type=['csv'], key='groundtruth_upload')
                if gt_upload is not None:
                    try:
                        truth = read_ground_truth(gt_upload.getvalue())
                        ev = evaluate_boxes(holds_df, truth)
                        a1, a2, a3 = st.columns(3)
                        a1.metric('Precision @ IoU 0.5', f"{ev['precision']:.1%}")
                        a2.metric('Recall @ IoU 0.5', f"{ev['recall']:.1%}")
                        a3.metric('F1 @ IoU 0.5', f"{ev['f1']:.1%}")
                        st.caption(f"Matched {ev['tp']} holds · {ev['fp']} false positives · {ev['fn']} missed holds. This compares the reviewed/suggested initial boxes only.")
                    except (ValueError, KeyError) as error:
                        st.error(f'Invalid ground-truth CSV: {error}')
            st.subheader('Possible hand/foot proximity to holds')
            st.caption('Near means close in the 2D image only. It does NOT confirm gripping, stepping, loading or physical contact.')
            if near_df.empty:
                st.info('No close landmark/hold pairs passed the distance threshold.')
            else:
                st.dataframe(near_df, hide_index=True, width='stretch')
                st.download_button('Download proximity CSV', near_df.to_csv(index=False).encode(),
                                   'climbvision_proximity.csv', 'text/csv', on_click='ignore')
        st.subheader('Climbing movement events (experimental)')
        st.caption('Hand/foot movements are projected landmark motion, not confirmed hold changes. Low-motion intervals are not necessarily rests. Missing or unreliable tracking produces missing events.')
        if events.empty:
            st.info('No events passed the conservative filters. This can happen with slow motion, short events, or partial tracking.')
        else:
            st.dataframe(events, width='stretch', hide_index=True)
        st.download_button('Download event timeline (CSV)', events.to_csv(index=False).encode(),
                           'climbvision_events.csv', 'text/csv', on_click='ignore')
        st.subheader('Hand and foot speeds')
        st.caption('Normalized image dimensions per second (camera-dependent). Gaps indicate missing data.')
        st.line_chart(metrics.set_index('time_s')[[f'{p}_speed' for p in ('left_hand','right_hand','left_foot','right_foot')]])
        st.subheader('Hip trajectory')
        st.line_chart(df.set_index('time_s')[['hip_x', 'hip_y']])
        st.subheader('Joint angles (2D)')
        st.line_chart(df.set_index('time_s')[['left_elbow', 'right_elbow', 'left_knee', 'right_knee']])
        st.subheader('Observations and review prompts')
        for tip in make_feedback(df):
            st.write('• ' + tip)
        st.download_button('Download measurements (CSV)', metrics.to_csv(index=False).encode(),
                           'climbvision_metrics.csv', 'text/csv', on_click='ignore')
