# ClimbVision v0.9.1 — Persistent full-result cache

This release saves a **completed** annotated MP4 and its tracking/measurement data under `~/.cache/climbvision/analyses/`. Reanalyzing exactly the same video, selected holds, ROI, pose model, FPS settings, tracker settings, and clip length can load the full result without running SAM 2, MediaPipe, or video encoding again. A cache hit is labeled in the results and progress indicator. Unsuccessful analyses are not saved. A **Delete all saved ClimbVision analyses** button is available under Manage analysis cache.

**Privacy:** The cache contains copies of annotated climbing videos and associated analysis. Stored video remains on your local computer until cleared. Be mindful when analyzing other people's footage.

**Limitation:** This is a completed-analysis cache, not yet independent pose/SAM stage caches. Changing any analysis setting—including a visual option that lives in analysis configuration—will cause a fresh run. Changing overlays without inference and dependency-aware partial reuse are planned for the rendering refactor. SAM 2 itself is not faster on a fresh run. The exact video and settings must match for reuse.

**Run on your M3 Mac:** Extract into Downloads, then activate the existing Python 3.11 environment and start Streamlit. No model redownload is needed if the environment and checkpoint remain available.

# ClimbVision v0.9.0

## Fast iteration workflow

Choose **Fast Preview (OpenCV, no SAM)** in the Hold tracking algorithm selector, **Lite** pose model, and **5 pose FPS**. Limit the preview to **3–10 seconds**. This bypasses SAM 2 entirely (no expensive neural mask propagation). Camera motion and 3D volumes can cause OpenCV alignment drift; do not regard fast preview as validated hold tracking. Videos retain the source FPS, but pose labels are only sampled at the chosen rate.

## Hold evaluation

Analyze a clip, download **ground-truth starter CSV** from results, and manually correct each `x,y,w,h` row (add missed true holds, remove false detections). Coordinates are expressed in the **resized analysis frame** (maximum dimension 960 pixels), not the source video resolution. Upload the CSV for first-frame detection precision, recall, F1 at IoU ≥ 0.5. Using model proposals without independent corrections as ground truth gives meaningless inflated results. This is **first-frame detection evaluation only**, not temporal tracking or pose accuracy.

## v0.7.3 sampling and export

- **Pose analysis FPS** (default 10) controls MediaPipe measurements.
- **SAM 2 inference FPS** (default 2) independently controls expensive mask tracking.
- The annotated video retains the original source FPS; optical flow bridges SAM anchor detections. Body pose is drawn only on sampled frames, so the skeleton will not be visually continuous yet.
- Use SAM 1–2 FPS, pose 10–15 FPS initially; accuracy and speed depend on camera motion and hardware.
- When SAM boxes are unreliable, the hybrid tracker suppresses them instead of claiming verified contact.

# ClimbVision v0.7.1 — Hybrid Preview (experimental)

This release preserves the original video FPS in the annotated MP4 while keeping expensive SAM 2 segmentation sparse. Between SAM keyframes, per-hold Lucas–Kanade optical flow follows the wall texture, and endpoint correction ensures alignment to the next SAM detection. If there are too many optical-flow failures or a hold is missing at either anchor, the hold box is suppressed rather than fabricated.

**Important:** The exported video looks smoother because all original frames are retained. Pose *measurements* are still sampled; the pose skeleton is shown only on measured frames. The annotated hold boxes between SAM frames are optical-flow estimates, not fresh segmentation masks. Processing is still slow when SAM 2 itself is slow.

**Mac M3 16 GB:** This version disables explicit CPU memory offloading in SAM initialization. If you run out of unified memory, restore `offload_video_to_cpu=True, offload_state_to_cpu=True` in `sam_tracker.py`, reduce the video length, or reduce tracked holds.

**What the Roboflow BoulderVision article adds:** It uses a *trained climbing-hold detector* (`climbing-route-1-hold-detection/6`), a hold-color classifier (`climbing-holds-onjbt/1`), and YOLO pose. Our current HSV candidates still cannot match that automatic detector. Future upgrades should evaluate a trained detector first, while respecting license, inference API, and whether its model can generalize to your gym. Reference: https://roboflow.com/blog/bouldering

## Running

This release updates the on-screen version label to v0.7.1, removes deprecated Streamlit width options, and displays both export FPS and pose sampling FPS next to the results. Annotated downloads include the release number in their filename. No hold-tracking algorithm changes were made in this packaging update.

Use the same Python environment and SAM 2 installation as v0.7. Run `streamlit run app.py`. Use the reviewed hold workflow; SAM 2 requires reviewed hold prompts.

# ClimbVision v0.7 — SAM 2.1 hold tracking (experimental)

**Status:** Experimental research prototype. No trained hold-recognition model is included.

## What's different
- **Wall registration:** OpenCV ORB descriptors + ratio-tested matching + RANSAC homography align each sampled frame to the first frame.
- **Tracked hold boxes:** Reviewed color suggestions or user-added boxes are transformed into the current frame. Hold identifiers stay stable.
- **Failure behavior:** If background alignment cannot be established, boxes and proximity records are suppressed for that frame, **not frozen** in stale locations.
- **Diagnostics:** Alignment success rate, feature-match counts, inlier counts, and visible hold counts can be exported as CSV.
- **Color suggestions:** Computed on the *first frame* (not a temporal median of moving camera frames), so hold coordinates correspond to the tracker reference.
- Retains in-browser annotated video playback, persistent analysis outputs, pose analysis, hold color sampling and hold editor.

## Install (macOS)

```bash
cd ~/Downloads/"climbvision 6"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app.py
```

Use a video with an identifiable, textured wall. Click one route-colored hold, generate color suggestions and remove incorrect boxes. Enable **Track the wall and move hold boxes with the camera** before analysis.

## Known limitations and research next steps
1. **Automatic recognition is still HSV segmentation, NOT trained AI.** Hold recall/precision is not yet validated, and manual corrections may remain necessary.
2. A homography assumes a mostly planar visible wall; multi-plane walls, occlusion and perspective/parallax shifts may invalidate alignment.
3. Fast camera movement, motion blur, low-texture backgrounds or changing illumination can cause tracking loss. No boxes are drawn if alignment fails.
4. When the wall moves relative to the camera, hip movement in image coordinates does not reflect pure climber movement. Motion compensation of body landmarks is future work.
5. Proximity is based on 2D coordinates only and does not establish physical contact.
6. A proper automatic detector requires a dedicated pretrained climbing-hold model (verified compatible weights) or labeled training data. Do not claim this version provides one.

## Testing
`python -m pytest -q test_wall_tracker.py test_holds.py test_review.py`

## v0.6.1 conservative color suggestion filters
- The hold suggestions now filter narrow tape-like regions, incomplete edge components, and loosely matched/fragmented color regions.
- The new **Advanced suggestion filtering** expander controls matching-color coverage, strip thickness and edge removal.
- These filters deliberately trade recall for fewer false positives: tiny/partial/adjacent holds may be missed.
- Suggestion filters only affect **Generate color-based suggestions**; manually reviewed holds remain editable.
- This is not a trained hold recognition model. Test the previews before analyzing and correct remaining errors.

---
## v0.7 — SAM 2.1 video tracking (experimental, Apple M3)

This release adds real **SAM 2.1 prompted video segmentation** as an alternative to OpenCV homography. It is not an automatic hold-recognition model: initial hold candidates are still color proposals and/or your corrections. SAM 2.1 then propagates a separate mask for each reviewed hold and gives it a persistent ID. It may fail during occlusion, viewpoint changes, or motion blur. **No accuracy results are claimed.**

### Fresh native Apple Silicon installation

Use a native arm64 Python **3.11** if possible. From Terminal:

```bash
cd ~/Downloads/"climbvision 7"
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install torch torchvision
cd ~/Downloads
git clone https://github.com/facebookresearch/sam2.git
cd sam2
python -m pip install -e .
mkdir -p checkpoints
curl -L --fail -o checkpoints/sam2.1_hiera_tiny.pt https://dl.fbaipublicfiles.com/segment_anything_2/092824/sam2.1_hiera_tiny.pt
cd ~/Downloads/"climbvision 7"
python -c "import torch; print('MPS available:', torch.backends.mps.is_available())"
streamlit run app.py
```

The **SAM 2.1 Tiny** model expects `sam2.1_hiera_tiny.pt`. If the download URL has changed, use the official download links in https://github.com/facebookresearch/sam2. The `Small` option requires the matching `sam2.1_hiera_small.pt` checkpoint instead. In the app set the checkpoint path (normally `~/Downloads/sam2/checkpoints/sam2.1_hiera_tiny.pt`).

Note: the official SAM 2 installation can report optional CUDA extension build warnings on Macs; CUDA-specific acceleration is not available on Apple Silicon. SAM 2's Apple Metal (MPS) execution may be slower or hit unsupported operations. If MPS fails, choose **cpu** for troubleshooting (slower). The code does **not** silently fall back to CPU, and it does not silently revert to the previous tracker. Do not enable indiscriminate MPS fallback without reviewing results.

### Workflow
1. Upload a short clip; start at **5 sampled FPS** and a few holds (four to six) to avoid exhausting unified memory. Prefer videos under thirty seconds.
2. Click a hold to sample route color, generate proposals, and keep only correct hold boxes. For missed holds, add a box with the hold editor. SAM 2 cannot infer the full route from one click by itself.
3. Choose **SAM 2.1 (AI masks)** under Hold tracking algorithm and choose Tiny / mps.
4. Click Analyze climb. Initial processing may take several minutes on an M3 MacBook Air and depends heavily on RAM, frame count, hold count and model execution.
5. Inspect the annotated video. If tracking drifts or an object is occluded, reduce prompts, try CPU, or shorten the clip. Hold proximity remains a 2D estimate, not proven contact.

**Technical details:** The adapter exports the same sampled JPEG frames that the application uses for pose tracking, runs SAM 2 forward from frame zero using the approved boxes as prompts, and converts segmentation masks to per-frame boxes. Empty or tiny masks are rejected. Segmentation boxes can still jitter, so this is not a guarantee of smooth or correct output. The original OpenCV tracker remains available for comparison.

### Testing

```bash
python -m unittest -v test_sam_tracker.py
python -m pytest -q test_holds.py test_review.py test_wall_tracker.py test_refined_holds.py test_sam_tracker.py
```

These tests validate the adapter's data processing, not the correctness or performance of the real SAM 2 checkpoint. Full inference must be validated on a Mac with a compatible PyTorch/SAM 2 installation.


## v0.7.3 patch
Fixed OpenCV rectangle errors when SAM 2 / optical flow output floating-point hold coordinates. Invalid or out-of-frame boxes are ignored in rendering. Tracking models are otherwise unchanged.

## v0.8.0 — browser progress, pose-overlay continuity, color sampling

- Under **Analyze climb**, Streamlit now displays the current pipeline stage and a progress bar. SAM 2 reports completed reference frames; subsequent stages include optical-flow generation, pose/render progress, event metrics, H.264 conversion. Percentages are coarse stage-weighted indicators, not estimated time remaining.
- To address blinking body skeletons in the exported original-FPS video, the latest **validated** MediaPipe pose is displayed on intervening non-analysis frames for up to 0.30 seconds. This is a **held prior estimate**, not newly inferred pose, and may lag quick moves. Measurements/CSV remain at selected Pose FPS. Stale poses disappear.
- The hold-color picker now offers **shadow-resistant color sampling**, enabled by default. It estimates hue from saturated/bright-enough pixels in a wider patch; for small holds near a different-colored wall, disable it or manually adjust color. It is still HSV selection, not AI hold identification. Preview proposals before analysis.
- New annotated download filename displays v0.8.0.
- SAM 2 performance and optional extension (`sam2._C`) remain unchanged, and SAM model weights are not bundled. Progress and display changes have not been end-to-end tested on an Apple M3.


## v0.8.0 optional trained hold suggestions (Roboflow)

This version offers **Trained hold detector (Roboflow)** in the hold review section. The selected model defaults to the BoulderVision project `climbing-route-1-hold-detection/6`, which is publicly listed on Roboflow Universe. The hosted API may require a Roboflow account, API key, credits and access permissions. We cannot guarantee access to that specific model with every account.

Install the optional SDK into your active ClimbVision Python environment:

```bash
python -m pip install inference-sdk
```

Paste your API key into the password field (never commit it to source control), click **Generate trained hold suggestions**, then manually review boxes before **Analyze climb**. Only the first video frame is sent to Roboflow for detection. ClimbVision then uses the existing SAM 2 / OpenCV hold tracker locally. Selecting a route color filters detected holds by HSV content within each trained detection box. Use **Legacy HSV color regions** to work completely offline.

Roboflow model performance statistics refer to its own data and do not guarantee accuracy on your indoor gym or overhanging walls. This integration has unit tests using simulated API responses but has NOT been validated with live Roboflow inference credentials or on your Mac.
